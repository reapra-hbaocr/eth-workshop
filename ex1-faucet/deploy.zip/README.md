---

## ex1-faucet 

* If you don't have faucet account yet. Run this cmd to create the faucet account.This command shoud be run once on the begining.If you already run this before, please skip this step.
```Sh
cd ex1-faucet
npm install
node generate_new_account.js
```

* After that transfer your ETH to this faucet account to use

* Run this cmd to start the faucet

```Sh
cd ex1-faucet
node index.js
```
